import argparse
from mzml2gnps.main import pipeline_test
    # Define the argument parser
def main():
    parser = argparse.ArgumentParser(description='Process mzML files for GNPS molecular networking.')
    parser.add_argument('--version', action='version', version='mzml2gnps 1.0.4')
    parser.add_argument('-i','--input_path', type=str, help='Input mzML file path or folder path containing mzML files')
    parser.add_argument('-o','--output_path', type=str, help='Output folder path')
    parser.add_argument('--correct', action='store_true', help='Correct precursors, default is False (use flag to enable)')
    parser.add_argument('--merge', action='store_true', help='Merge spectra, default is False (use flag to enable)')
    parser.add_argument('--precmz', type=str, default=None, help='CSV file path for list of precursor m/z values')
    parser.add_argument('--rt', type=str, default=None, help='CSV file path for list of retention times')
    parser.add_argument('--precmz_tolerance', type=float, default=20, help='Precursor m/z tolerance (in ppm)')
    parser.add_argument('--rt_tolerance', type=float, default=0.5, help='Retention time tolerance (in seconds)')
    parser.add_argument('--precinty_thre', type=float, default=0, help='Precursor intensity threshold')
    parser.add_argument('--csv', type=str, default=None, help='CSV file path including precmz and rt columns, default is None')
    args = parser.parse_args()

    pipeline_test(args)

if __name__ == '__main__':
    main()